# Payments reconciliation (Onelab AI Fitness Assessment)

    pip install -r requirements.txt
    python generate_data.py          # writes data/*.csv (+ ground_truth.json for tests only)
    python reconcile.py              # prints the bridge, writes output/findings.csv + bridge.csv
    pytest -q                        # 19 tests
    streamlit run app.py             # UI

See PROMPTS.md for the prompts, assumptions, demo script and production caveats.
